// Select elements
const nameField = document.querySelector('.namefield');
const nameInput = document.querySelector('.namefield input');
const emailInput = document.querySelector('input[type="email"]');
const passwordInput = document.querySelector('input[type="password"]');
const signupBtn = document.querySelector('.signupbtn');
const signinBtn = document.querySelector('.signinbtn');
const title = document.querySelector('.title');
let underline=document.querySelector('.underline');
let text=document.querySelector('.text');
// Track mode: Sign Up or Sign In
let isSignUp = true;

// Switch to Sign In mode
signinBtn.addEventListener('click', () => {
  isSignUp = false;
  nameField.style.maxHeight = '0';
  title.textContent = 'Sign In';
  text.innerHTML='Lost Password';
  signupBtn.classList.add('disable');
  signinBtn.classList.remove('disable');
  underline.style.transform= 'translateX(35px)';
});

// Switch to Sign Up mode
signupBtn.addEventListener('click', () => {
  if (!isSignUp) {
    isSignUp = true;
    nameField.style.maxHeight = '60px';
    title.textContent = 'Sign Up';
     text.innerHTML='Password Suggestions';
    signupBtn.classList.remove('disable');
    signinBtn.classList.add('disable');
    underline.style.transform='translateX(0)';
    return;
  }

  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  const password = passwordInput.value;

  if (!name || !email || !password) {
    alert('Please fill in all fields.');
    return;
  }

  let users = JSON.parse(localStorage.getItem('users') || '{}');

  if (users[email]) {
    alert('User already registered. Please sign in.');
  } else {
    users[email] = { name, password };
    localStorage.setItem('users', JSON.stringify(users));
    alert('Registration successful! Now switch to Sign In.');
  }
});

// Login process
signinBtn.addEventListener('click', () => {
  if (isSignUp) return;

  const email = emailInput.value.trim();
  const password = passwordInput.value;

  if (!email || !password) {
    alert('Please enter email and password.');
    return;
  }

  let users = JSON.parse(localStorage.getItem('users') || '{}');

  if (users[email] && users[email].password === password) {
    alert(`Welcome, ${users[email].name}! Accessing secured page...`);
    showSecuredPage(users[email].name);
  } else {
    alert('Invalid credentials.');
  }
});

// Function to show secured content
function showSecuredPage(username) {
  document.querySelector('.form-box').innerHTML = `
    <h2>Welcome, ${username}!</h2>
    <p>This is a secured page. You are successfully logged in.</p>
    <button onclick="logout()">Logout</button>
  `;
}

// Logout function
function logout() {
  window.location.reload();
}
